import React from 'react';
import PropTypes from 'prop-types';

const Blog = ({ blog, handleLike, handleDelete }) => {
  // If the blog is not defined or does not have an id, do not render the component
  if (!blog || !blog.id) {
    return <p>No blog data available</p>;
  }

  const formattedUrl = blog.url.startsWith('http') ? blog.url : `http://${blog.url}`;

  return (
    <div>
      <h3>{blog.title}</h3>
      <p>Author: {blog.author}</p>
      <p>
        {blog.url ? (
          <a href={formattedUrl} target="_blank" rel="noopener noreferrer">
            {blog.url}
          </a>
        ) : (
          'No URL available'
        )}
      </p>
      <p>Likes: {blog.likes}</p>
      <button 
        onClick={() => handleLike(blog.id)} // Pass blog id to handleLike
        aria-label={`Like ${blog.title}`}
      >
        Like
      </button>
      <button 
        onClick={() => handleDelete(blog.id)} // Pass blog id to handleDelete
        aria-label={`Delete ${blog.title}`}
      >
        Delete
      </button>
    </div>
  );
};

Blog.propTypes = {
  blog: PropTypes.shape({
    id: PropTypes.string.isRequired,
    title: PropTypes.string.isRequired,
    author: PropTypes.string.isRequired,
    url: PropTypes.string, // Make url optional in propTypes
    likes: PropTypes.number.isRequired,
  }).isRequired,
  handleLike: PropTypes.func.isRequired,
  handleDelete: PropTypes.func.isRequired,
};

export default Blog;
