// src/components/BlogView.jsx
import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import blogService from '../services/blogs';
import CommentForm from './CommentForm';

const BlogView = () => {
  const { id } = useParams();
  const [blog, setBlog] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchBlog = async () => {
      try {
        console.log('Fetching blog with ID:', id); // Debugging log
        const fetchedBlog = await blogService.getById(id);
        setBlog(fetchedBlog);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching blog:', error);
        setError('Error fetching blog. Please try again later.');
        setLoading(false);
      }
    };

    fetchBlog();
  }, [id]);

  const handleLike = async () => {
    try {
      const updatedBlog = await blogService.like(id);
      setBlog(updatedBlog);
    } catch (error) {
      console.error('Error liking blog:', error);
      setError('Error liking blog. Please try again later.');
    }
  };

  const handleAddComment = async (comment) => {
    try {
      console.log('Adding comment:', comment); // Debugging log
      const updatedBlog = await blogService.addComment(id, comment);
      console.log('Updated blog after comment:', updatedBlog); // Debugging log
      setBlog(updatedBlog);
    } catch (error) {
      console.error('Error adding comment:', error);
      setError('Error adding comment. Please try again later.');
    }
  };

  if (loading) {
    return <p>Loading...</p>;
  }

  if (error) {
    return <p>{error}</p>;
  }

  if (!blog) {
    return <p>Blog not found</p>;
  }
 
  console.log('Rendering BlogView'); // Debugging log

  return ( 
    <div>
      <h2>{blog.title}</h2>
      <p><strong>Author:</strong> {blog.author}</p>
      <p><strong>URL:</strong> <a href={blog.url} target="_blank" rel="noopener noreferrer">{blog.url}</a></p>
      <p><strong>Likes:</strong> {blog.likes} <button onClick={handleLike}>Like</button></p>

      <h3>Comments</h3>
      <ul>
        {blog.comments && blog.comments.length > 0 ? (
          blog.comments.map((comment, index) => (
            <li key={index}>{comment.content}</li>
          ))
        ) : (
          <p>No comments yet</p>
        )}
      </ul>

      <CommentForm handleAddComment={handleAddComment} />
    </div>
  );
};

export default BlogView;
