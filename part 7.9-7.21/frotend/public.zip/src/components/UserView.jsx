// src/components/UserView.jsx
import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useParams } from 'react-router-dom';
import { initializeUsers } from '../reducers/usersReducer';
import Blog from './Blog';

const UserView = () => {
  const { id } = useParams();
  const [loading, setLoading] = useState(true);
  const users = useSelector((state) => state.users);
  const dispatch = useDispatch();

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        await dispatch(initializeUsers()); // Ensure this fetches users
        setLoading(false);
      } catch (error) {
        console.error('Error fetching users:', error);
        setLoading(false);
      }
    };

    fetchUsers();
  }, [dispatch]);

  const user = users.find((u) => u.id === id);

  if (loading) {
    return <p>Loading user data...</p>;
  }

  if (!user) {
    return <p>User not found</p>;
  }

  return (
    <div>
      <h2>{user.name}</h2>
      <h3>Blogs created:</h3>
      {user.blogs.length === 0 ? (
        <p>No blogs created</p>
      ) : (
        <ul>
          {user.blogs.map((blog) => (
            <li key={blog.id}>
              <Blog blog={blog} handleLike={() => {}} handleDelete={() => {}} />
            </li>
          ))}
        </ul>
      )}
    </div>
  );
};

export default UserView;
